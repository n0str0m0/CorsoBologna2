﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Corso.Bologna.Models;
using Corso.Bologna.Services;
using GalaSoft.MvvmLight;

namespace Corso.Bologna.ViewModels
{
    public class MainViewModel: ViewModelBase
    {
        private IList<Recipe> _recipes;
        private Recipe _selecedRecipe;
        private int _selectedIndex;

        public MainViewModel()
        {
            Title = nameof(MainViewModel);
            LoadDataAsync();
        }

        public async void LoadDataAsync()
        {
            Recipes = await new RecipeService().GetRecipeAsync();
        }
        public string Title { get; set; }

        public Recipe SelectedRecipe
        {
            get { return _selecedRecipe; }
            set { Set(ref _selecedRecipe, value); }
        }

        public int SelectedIndex
        {
            get { return _selectedIndex; }
            set
            {
                if (Recipes != null)
                {
                    SelectedRecipe = Recipes[value];
                }
                Set(ref _selectedIndex, value);
            }

        }
        public IList<Recipe> Recipes
        {
            get { return _recipes; }
            set
            {
                       
                Set(ref _recipes, value);
            }
        }
    }
}
